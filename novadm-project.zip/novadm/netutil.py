"""HTTPS helpers: certificate store that also works on PCs with outdated Windows root certificates."""
import os
import ssl
import urllib.request

from .engine_ua import UA

_ctx = None
_ctx_insecure = None

CERT_HELP = ("Security certificate problem: the site's certificate could not be verified. Your PC's date/time or its "
             "Windows root certificates may be outdated. If you trust this site, use 'Retry without certificate check'.")


def ssl_context(insecure: bool = False):
    global _ctx, _ctx_insecure
    if insecure:
        if _ctx_insecure is None:
            c = ssl.create_default_context()
            c.check_hostname = False
            c.verify_mode = ssl.CERT_NONE
            _ctx_insecure = c
        return _ctx_insecure
    if _ctx is None:
        c = ssl.create_default_context()           # Windows certificate store
        try:
            import certifi
            c.load_verify_locations(cafile=certifi.where())   # + Mozilla bundle: fixes old/expired chains
        except Exception:
            pass
        _ctx = c
    return _ctx


def is_cert_error(e) -> bool:
    seen = 0
    while e is not None and seen < 6:
        if isinstance(e, ssl.SSLCertVerificationError) or "CERTIFICATE_VERIFY_FAILED" in str(e):
            return True
        e = getattr(e, "reason", None) if not isinstance(getattr(e, "reason", None), str) else None
        seen += 1
    return False


def download_file(url, dest, progress=None, timeout=60):
    """Download url -> dest (via .part). progress(done, total). Raises on failure."""
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    tmp = dest + ".part"
    req = urllib.request.Request(url, headers={"User-Agent": UA})
    with urllib.request.urlopen(req, timeout=timeout, context=ssl_context()) as r, open(tmp, "wb") as f:
        total = int(r.headers.get("Content-Length") or 0)
        done = 0
        while True:
            b = r.read(256 * 1024)
            if not b:
                break
            f.write(b)
            done += len(b)
            if progress:
                progress(done, total)
    os.replace(tmp, dest)
