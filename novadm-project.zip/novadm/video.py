"""Video / audio downloads through the official yt-dlp program (+ ffmpeg + deno), run as a separate process.
Using the standalone yt-dlp.exe keeps it self-contained and updatable (YouTube changes often)."""
import json
import os
import re
import shutil
import subprocess
import sys
import threading
import time
import zipfile

from .config import category_of, data_dir
from .engine import Download
from .engine import sanitize
from .engine_ua import UA
from .netutil import download_file

IS_WIN = sys.platform.startswith("win")
EXE = ".exe" if IS_WIN else ""
NO_WINDOW = 0x08000000 if IS_WIN else 0
HEIGHTS = (2160, 1440, 1080, 720, 480, 360, 240)

URL_YTDLP = "https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp.exe"
URL_DENO = "https://github.com/denoland/deno/releases/latest/download/deno-x86_64-pc-windows-msvc.zip"
URLS_FFMPEG = [
    "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip",
    "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
]


# ----------------------------------------------------------------------------- tools
def tools_dirs():
    dirs = []
    env = os.environ.get("NOVADM_TOOLS")
    if env:
        dirs.append(env)
    dirs.append(os.path.join(data_dir(), "tools"))                 # tools updated by the user come first
    if getattr(sys, "frozen", False):
        dirs.append(os.path.join(os.path.dirname(sys.executable), "tools"))   # tools shipped with the installer
    else:
        dirs.append(os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "tools"))
    return dirs


def find_tool(name):
    for d in tools_dirs():
        p = os.path.join(d, name + EXE)
        if os.path.isfile(p):
            return p
    return shutil.which(name)


def tools_status():
    return {"ytdlp": bool(find_tool("yt-dlp")), "ffmpeg": bool(find_tool("ffmpeg")), "deno": bool(find_tool("deno"))}


def _target_dir():
    d = os.path.join(data_dir(), "tools")
    os.makedirs(d, exist_ok=True)
    return d


def _extract(zip_path, wanted, dest_dir):
    got = 0
    with zipfile.ZipFile(zip_path) as z:
        for n in z.namelist():
            base = os.path.basename(n).lower()
            if base in wanted and not n.endswith("/"):
                with z.open(n) as src, open(os.path.join(dest_dir, base), "wb") as out:
                    shutil.copyfileobj(src, out)
                got += 1
    return got


def install_tools(progress, update=False):
    """Download yt-dlp, deno and ffmpeg into the app-data tools folder. progress(pct, message)."""
    dest = _target_dir()
    steps = []
    if update or not find_tool("yt-dlp"):
        steps.append("yt-dlp")
    if not find_tool("deno"):
        steps.append("deno")
    if not find_tool("ffmpeg"):
        steps.append("ffmpeg")
    if not steps:
        progress(100, "Everything is installed")
        return
    for i, name in enumerate(steps):
        lo, hi = i * 100 // len(steps), (i + 1) * 100 // len(steps)

        def prog(done, total, name=name, lo=lo, hi=hi):
            pct = lo + (hi - lo) * (done / total if total else 0.5)
            progress(pct, "Downloading %s... %s MB" % (name, done // (1024 * 1024)))

        if name == "yt-dlp":
            download_file(URL_YTDLP, os.path.join(dest, "yt-dlp" + EXE), prog)
        elif name == "deno":
            z = os.path.join(dest, "deno.zip")
            download_file(URL_DENO, z, prog)
            _extract(z, {"deno.exe"}, dest)
            os.remove(z)
        else:
            last = None
            for u in URLS_FFMPEG:
                z = os.path.join(dest, "ffmpeg.zip")
                try:
                    download_file(u, z, prog)
                    if _extract(z, {"ffmpeg.exe", "ffprobe.exe"}, dest) >= 1:
                        os.remove(z)
                        last = None
                        break
                except Exception as e:  # noqa
                    last = e
                    try:
                        os.remove(z)
                    except OSError:
                        pass
            if last is not None:
                raise last
    progress(100, "Done")


# ----------------------------------------------------------------------------- yt-dlp command
def _clean_error(text: str) -> str:
    lines = [l.strip() for l in (text or "").splitlines() if l.strip()]
    errs = [l for l in lines if l.startswith("ERROR")]
    msg = (errs[-1] if errs else (lines[-1] if lines else "Video download failed"))
    msg = re.sub(r"^ERROR:\s*(\[[^\]]+\]\s*)?", "", msg)
    low = msg.lower()
    if "requested format is not available" in low or "javascript" in low or "n challenge" in low or "sign in" in low and "bot" in low:
        msg += "  -  Try 'Update video tools' (YouTube changes often) and make sure deno + ffmpeg are installed."
    return msg[:400]


def base_cmd(extra_cookie=""):
    yt = find_tool("yt-dlp")
    cmd = [yt, "--no-warnings", "--no-colors", "--no-playlist", "--encoding", "utf-8"]
    deno = find_tool("deno")
    if deno:
        cmd += ["--js-runtimes", "deno:" + deno]
    ff = find_tool("ffmpeg")
    if ff:
        cmd += ["--ffmpeg-location", os.path.dirname(ff)]
    if extra_cookie:
        cmd += ["--add-header", "Cookie:" + extra_cookie]
    return cmd


def video_info(url: str, cookie: str = "") -> dict:
    yt = find_tool("yt-dlp")
    if not yt:
        raise ValueError("Video tools are not installed yet. Click 'Install video tools' below.")
    p = subprocess.run(base_cmd(cookie) + ["-J", url], capture_output=True, timeout=120, creationflags=NO_WINDOW)
    out = p.stdout.decode("utf-8", "replace")
    if p.returncode != 0 or not out.strip():
        raise ValueError(_clean_error(p.stderr.decode("utf-8", "replace")))
    info = json.loads(out)
    if info.get("entries"):
        info = next((e for e in info["entries"] if e), info)
    top = 0
    for f in info.get("formats") or []:
        if f.get("height") and f.get("vcodec") not in (None, "none"):
            top = max(top, f["height"])
    ff = bool(find_tool("ffmpeg"))
    options = [{"id": "best", "label": "Best available quality"}]
    for h in HEIGHTS:
        if h <= top:
            options.append({"id": str(h), "label": f"{h}p"})
    options.append({"id": "audio", "label": "Audio only (MP3)" if ff else "Audio only (original format)"})
    return {"title": info.get("title") or "video", "duration": info.get("duration") or 0,
            "uploader": info.get("uploader") or "", "thumbnail": info.get("thumbnail") or "",
            "options": options, "has_ffmpeg": ff}


def format_for(choice: str, ff: bool):
    if choice == "audio":
        return "ba/b", True
    if choice in ("best", "", None):
        return ("bv*+ba/b" if ff else "b/bv*"), False
    h = int(choice)
    if ff:
        return f"bv*[height<={h}]+ba/b[height<={h}]/bv*+ba/b", False
    return f"b[height<={h}]/b/bv*", False


# ----------------------------------------------------------------------------- the download
class VideoDownload(Download):
    kind = "video"

    def __init__(self, url, folder, **opt):
        super().__init__(url, folder, **opt)
        self._base = 0
        self._cur = 0
        self._last_cur = 0
        self.proc = None
        if not self.name:
            self.name = "Video (fetching info...)"
        self.cat = "Music" if self.vfmt == "audio" else "Video"
        self.resumable = True

    @property
    def downloaded(self):
        if self.status == "completed":
            return max(self.size, 0)
        return self._base + self._cur

    def sample(self, now):
        if self.status != "downloading":
            self.speed = 0.0

    def pause(self):
        self.stop_evt.set()
        p = self.proc
        if p is not None and p.poll() is None:
            try:
                p.terminate()
            except Exception:
                pass
        if not self.active and self.status in ("queued", "downloading", "scheduled"):
            self.status = "paused"

    def delete_files(self):
        for p in (self.path, (self.path + ".part") if self.path else ""):
            if p:
                try:
                    os.remove(p)
                except OSError:
                    pass

    @staticmethod
    def _num(x):
        try:
            return float(x)
        except (TypeError, ValueError):
            return 0.0

    def _spawn(self, with_format: bool):
        yt = find_tool("yt-dlp")
        ff = bool(find_tool("ffmpeg"))
        fmt, audio = format_for(self.vfmt, ff)
        os.makedirs(self.folder, exist_ok=True)
        tmpl = "NDM|%(progress.downloaded_bytes)s|%(progress.total_bytes)s|%(progress.total_bytes_estimate)s|%(progress.speed)s|%(info.title)s"
        cmd = base_cmd(self.cookie) + [
            "--newline", "--progress", "-c", "--windows-filenames", "--retries", "10", "--fragment-retries", "10",
            "--concurrent-fragments", "4", "--socket-timeout", "30",
            "-o", os.path.join(self.folder, "%(title).150B [%(id)s].%(ext)s"),
            "--progress-template", "download:" + tmpl,
            "--print", "after_move:NDMFILE|%(filepath)s",
            "--user-agent", self.ua or UA,
        ]
        if self.referer:
            cmd += ["--referer", self.referer]
        if with_format:
            cmd += ["-f", fmt]
        if audio and ff:
            cmd += ["-x", "--audio-format", "mp3", "--audio-quality", "0"]
        from .engine import LIMITER
        if LIMITER.rate:
            cmd += ["--limit-rate", str(LIMITER.rate)]
        if self.insecure:
            cmd += ["--no-check-certificates"]
        cmd.append(self.url)
        self._base = self._cur = self._last_cur = 0
        self.proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, creationflags=NO_WINDOW,
                                     bufsize=1)
        tail = []
        final = None
        for raw in iter(self.proc.stdout.readline, b""):
            line = raw.decode("utf-8", "replace").rstrip()
            if line.startswith("NDM|"):
                p = line.split("|", 5)
                if len(p) == 6:
                    cur = int(self._num(p[1]))
                    if cur < self._last_cur - 1024:          # a new stream (audio after video) started
                        self._base += self._last_cur
                    self._last_cur = cur
                    self._cur = cur
                    total = self._num(p[2]) or self._num(p[3])
                    if total:
                        self.size = max(self.size, int(total) + self._base)
                    sp = self._num(p[4])
                    if sp:
                        self.speed = sp
                    if p[5] and p[5] != "NA" and self.name.startswith("Video ("):
                        self.name = sanitize(p[5])
            elif line.startswith("NDMFILE|"):
                final = line.split("|", 1)[1].strip()
            elif line:
                tail.append(line)
                tail = tail[-12:]
            if self.stop_evt.is_set() and self.proc.poll() is None:
                self.proc.terminate()
        rc = self.proc.wait()
        return rc, "\n".join(tail), final

    def _run(self):
        if not find_tool("yt-dlp"):
            self.error = "Video tools are not installed. Open 'Video' and click 'Install video tools'."
            self.status = "error"
            return
        self.last_try = time.time()
        try:
            if self.auto_sort:
                self.folder = os.path.join(self.folder, self.cat)
                self.auto_sort = False
            rc, err, final = self._spawn(True)
            if rc != 0 and not self.stop_evt.is_set() and "format is not available" in err.lower():
                rc, err, final = self._spawn(False)             # let yt-dlp choose by itself
            if self.stop_evt.is_set() and rc != 0:
                self.status = "paused"
                return
            if rc != 0:
                self.error = _clean_error(err)
                self.status = "error"
                return
            if final and os.path.isfile(final):
                self.path = final
                self.name = os.path.basename(final)
                self.cat = category_of(self.name)
                self.size = os.path.getsize(final)
                self.status = "completed"
                self.completed_at = time.time()
                self.speed = 0.0
            else:
                self.error = "The video file was not created"
                self.status = "error"
        except Exception as e:  # noqa
            self.error = (str(e) or e.__class__.__name__)[:300]
            self.status = "error"
